"""Runs tool commands with per-tool logging, timeouts and a small thread pool."""

from __future__ import annotations

import os
import subprocess
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

from . import tools


@dataclass
class ToolResult:
    name: str
    status: str  # ok | fail | skipped
    reason: str = ""
    seconds: float = 0.0
    rc: int | None = None
    log: str = ""
    cmd: list = field(default_factory=list)


def tail_text(path, lines=12, limit=2000):
    try:
        data = Path(path).read_text(errors="replace").splitlines()
    except OSError:
        return ""
    return "\n".join(data[-lines:])[-limit:]


def run_command(cmd, logfile, timeout):
    logfile = Path(logfile)
    logfile.parent.mkdir(parents=True, exist_ok=True)
    started = time.time()
    rc = None
    try:
        with logfile.open("w") as fh:
            proc = subprocess.Popen(
                cmd,
                stdout=fh,
                stderr=subprocess.STDOUT,
                stdin=subprocess.DEVNULL,
                env=os.environ,
            )
            try:
                rc = proc.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                proc.terminate()
                try:
                    proc.wait(timeout=15)
                except subprocess.TimeoutExpired:
                    proc.kill()
                rc = 124
    except FileNotFoundError:
        rc = 127
    return rc, time.time() - started


def run_tool(name, cmd, log_path, timeout, verify=None) -> ToolResult:
    stamp = datetime.now().strftime("%H:%M:%S")
    print(f"[{stamp}] [{name}] start: {tools._q(cmd)}")
    rc, elapsed = run_command(cmd, log_path, timeout)
    stamp = datetime.now().strftime("%H:%M:%S")
    if rc == 0:
        if verify is not None:
            ok, why = verify(cmd)
            if not ok:
                print(f"[{stamp}] [{name}] FAILED rc=0 after {elapsed:.0f}s (log: {log_path}): {why}")
                tail = tail_text(log_path)
                if tail:
                    for line in tail.splitlines()[-6:]:
                        print(f"    {name}: {line}")
                return ToolResult(name=name, status="fail", reason=why, seconds=elapsed, rc=0,
                                  log=str(log_path), cmd=cmd)
        print(f"[{stamp}] [{name}] done in {elapsed:.0f}s")
        return ToolResult(name=name, status="ok", seconds=elapsed, rc=0, log=str(log_path), cmd=cmd)
    print(f"[{stamp}] [{name}] FAILED rc={rc} after {elapsed:.0f}s (log: {log_path})")
    tail = tail_text(log_path)
    if tail:
        for line in tail.splitlines()[-8:]:
            print(f"    {name}: {line}")
    return ToolResult(name=name, status="fail", seconds=elapsed, rc=rc, log=str(log_path), cmd=cmd)


def run_passive(domain, raw, logs, opts) -> list[ToolResult]:
    """Run the passive tools for one domain in parallel; returns ToolResults (incl. skips)."""
    builders = [
        ("subfinder", lambda: tools.build_subfinder(domain, raw, opts)),
        ("bbot", lambda: tools.build_bbot(domain, raw, opts, datetime.now().strftime("%Y%m%d-%H%M%S"))),
        ("waymore", lambda: tools.build_waymore(domain, raw, opts, datetime.now().strftime("%Y%m%d-%H%M%S"))),
        ("cloud_enum", lambda: tools.build_cloud_enum(domain, raw, opts, datetime.now().strftime("%Y%m%d-%H%M%S"))),
    ]
    results: list[ToolResult] = []
    pending = []
    for name, fn in builders:
        if name not in opts.enabled_passive:
            results.append(ToolResult(name=name, status="skipped", reason="disabled by --only/--skip"))
            continue
        cmd, why = fn()
        if cmd is None:
            results.append(ToolResult(name=name, status="skipped", reason=why or "unavailable"))
        else:
            pending.append((name, cmd))
    if pending:
        workers = max(1, min(int(opts.max_workers), len(pending)))
        stamp = datetime.now().strftime("%H:%M:%S")
        print(f"[{stamp}] [{domain}] launching {len(pending)} tool(s) with {workers} worker(s)")
        with ThreadPoolExecutor(max_workers=workers) as pool:
            futures = {
                pool.submit(run_tool, name, cmd, Path(logs) / f"{name}.log", opts.tool_timeout,
                            verify=tools.verify_bbot if name == "bbot" else None): name
                for name, cmd in pending
            }
            for fut in as_completed(futures):
                results.append(fut.result())
    order = {name: i for i, (name, _) in enumerate(builders)}
    results.sort(key=lambda r: order.get(r.name, 99))
    return results
