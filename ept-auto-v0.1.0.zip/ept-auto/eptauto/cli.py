"""Command-line interface: run recon per domain, install tools, inspect status."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from . import consolidate, install, runner, tools

VERSION = "0.1.0"
ALL_TOOLS = ["subfinder", "bbot", "waymore", "cloud_enum", "eyewitness"]
PASSIVE_TOOLS = ALL_TOOLS[:-1]


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="ept-auto",
        description=(
            "External perimeter recon in one shot: subfinder + BBOT + waymore + cloud_enum "
            "+ EyeWitness, consolidated into clean lists per domain."
        ),
    )
    p.add_argument("domains", nargs="*", help="one or more target domains (or use --file)")
    p.add_argument("-f", "--file", help="file with one domain per line")
    p.add_argument("--outdir", default="output", help="output root (default: ./output)")
    p.add_argument("--skip", default="", help="comma-separated tools to skip")
    p.add_argument("--only", default="", help="comma-separated tools to run (e.g. subfinder,waymore)")
    p.add_argument("--no-eyewitness", action="store_true", help="skip the EyeWitness stage entirely")
    p.add_argument("--max-workers", type=int, default=4, help="parallel tool workers per domain")
    p.add_argument("--tool-timeout", type=int, default=21600, help="per-tool timeout in seconds")
    p.add_argument("--consolidate-only", action="store_true", help="rebuild combined outputs from existing raw data and exit")
    p.add_argument("--install", nargs="*", default=None, metavar="TOOL",
                   help="install all (or only the listed) tools, then exit")
    p.add_argument("--list-tools", action="store_true", help="show tool availability and paths")
    p.add_argument("--check", default=None, nargs="?", const="", metavar="TOOL",
                   help="deep-verify tool executables actually run (empty = all). exits 1 on failures")
    p.add_argument("--version", action="version", version=f"%(prog)s {VERSION}")

    g = p.add_argument_group("tool options")
    g.add_argument("--subfinder-all", action="store_true", help="subfinder: use all sources, not just curated")
    g.add_argument("--subfinder-max-time", type=int, default=20, help="subfinder -max-time minutes (default 20)")
    g.add_argument("--bbot-presets", default=tools.DEFAULT_BBOT_PRESETS,
                   help=f"comma list of BBOT presets (default: {tools.DEFAULT_BBOT_PRESETS})")
    g.add_argument("--waymore-mode", choices=["U", "B"], default="U", help="U=urls only (fast), B=+archived responses")
    g.add_argument("--waymore-limit-requests", type=int, default=50000, help="waymore -lr per-source request cap")
    g.add_argument("--waymore-append", action="store_true", help="append to existing waymore.txt instead of overwriting")
    g.add_argument("--cloud-quickscan", action="store_true", help="cloud_enum: disable mutations/second-level scans")
    g.add_argument("--cloud-threads", type=int, default=10, help="cloud_enum -t thread count")
    g.add_argument("--cloud-keyword", action="append", default=[], help="extra cloud_enum -k keyword (repeatable)")
    g.add_argument("--cloud-mutations", default="", help="custom cloud_enum -m mutations file")
    g.add_argument("--eyewitness-threads", type=int, default=0, help="EyeWitness --threads (0=auto)")
    g.add_argument("--eyewitness-limit", type=int, default=2000, help="max URLs handed to EyeWitness")
    return p


def resolve_enabled(opts) -> set[str]:
    allowed = ({t.strip() for t in opts.only.split(",") if t.strip()} if opts.only else set(ALL_TOOLS))
    if opts.skip:
        allowed -= {t.strip() for t in opts.skip.split(",") if t.strip()}
    unknown = allowed - set(ALL_TOOLS)
    if unknown:
        raise SystemExit(f"unknown tool name(s): {', '.join(sorted(unknown))}. "
                         f"valid: {', '.join(ALL_TOOLS)}")
    if opts.no_eyewitness:
        allowed.discard("eyewitness")
    return allowed


def collect_domains(opts) -> list[str]:
    domains = []
    seen = set()
    for entry in opts.domains:
        d = normalize_domain(entry)
        if d and d not in seen:
            domains.append(d)
            seen.add(d)
    if opts.file:
        for line in Path(opts.file).read_text(errors="replace").splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            d = normalize_domain(line)
            if d and d not in seen:
                domains.append(d)
                seen.add(d)
    return domains


def normalize_domain(raw_entry: str) -> str:
    d = raw_entry.strip()
    for prefix in ("http://", "https://"):
        if d.lower().startswith(prefix):
            d = d[len(prefix):]
    d = d.split("/", 1)[0].strip().rstrip(".").lower()
    if not d:
        return ""
    if not all(part and len(part) <= 63 for part in d.split(".")):
        raise SystemExit(f"invalid domain: {raw_entry!r}")
    return d


def run_checks(which=()) -> int:
    """Execute each tool's --version/-h; print requirements for anything broken."""
    names = list(which) if which else list(ALL_TOOLS)
    print("tool checks (executing each tool to prove it runs):")
    failures = []
    for name in names:
        if name not in ALL_TOOLS:
            print(f"  {name:<10} unknown tool")
            failures.append(name)
            continue
        ok, detail = tools.tool_ok(name)
        print(f"  {name:<10} {'OK' if ok else 'BROKEN'}  {detail}")
        if not ok:
            failures.append(name)
    if failures:
        print("\nrequirements:")
        for name in failures:
            if name in ALL_TOOLS:
                print(f"  {name:<10} {tools.TOOL_FIX_HINTS[name]}")
            else:
                print(f"  {name:<10} not a valid tool name ({', '.join(ALL_TOOLS)})")
        print("\nor install all: sudo ./ept-auto.sh --install")
        return 1
    print("\nall tools callable")
    return 0


def preflight(enabled: set):
    """Warn (non-blocking) about enabled tools that will be skipped."""
    issues = []
    for name in sorted(enabled):
        ok, detail = tools.tool_ok(name)
        if not ok:
            issues.append((name, detail))
    return issues


def list_tools() -> int:
    print("tool availability:")
    missing = []
    for name, label, bin_path in tools.list_status():
        state = bin_path if bin_path else "MISSING"
        if not bin_path:
            missing.append(name)
        print(f"  {name:<10} {state}")
        print(f"             {label} - {tools.TOOL_URLS[name]}")
    loc = tools.eyewitness_location()
    if loc:
        print(f"  eyewitness: {loc['mode']} install at {loc['root']}")
    else:
        print(f"  eyewitness: NOT FOUND — {tools.eyewitness_requirement()}")
    if missing:
        print("\nrequirements for missing tools:")
        for name in missing:
            print(f"  {name:<10} {tools.TOOL_FIX_HINTS.get(name, 'see ' + tools.TOOL_URLS[name])}")
        print("\nor install all: ./ept-auto.sh --install")
    return 0


def status_line(result: runner.ToolResult) -> str:
    base = f"  {result.status.upper():<8} {result.name}"
    if result.reason:
        return f"{base} - {result.reason}"
    extra = []
    if result.rc is not None:
        extra.append(f"rc={result.rc}")
    if result.seconds:
        extra.append(f"{result.seconds:.0f}s")
    return f"{base} {' '.join(extra)}"


def run_domain(domain: str, outroot: Path, opts) -> tuple[list[runner.ToolResult], dict]:
    domain_dir = outroot / domain
    raw = domain_dir / "raw"
    logs = raw / "logs"
    combined = domain_dir / "combined"
    for d in (raw, logs, combined):
        d.mkdir(parents=True, exist_ok=True)

    results: list[runner.ToolResult] = []
    if not opts.consolidate_only:
        results = runner.run_passive(domain, raw, logs, opts)

    dd = consolidate.consolidate_raw(domain, domain_dir)

    if not opts.consolidate_only and "eyewitness" in opts.enabled_all and dd.subdomains:
        urls = consolidate.build_probe_list(dd, opts.eyewitness_limit)
        (raw / "urls_for_eyewitness.txt").write_text("\n".join(urls) + "\n")
        cmd, why = tools.build_eyewitness(domain, raw, opts)
        if cmd is None:
            results.append(runner.ToolResult(name="eyewitness", status="skipped", reason=why or ""))
        else:
            results.append(runner.run_tool("eyewitness", cmd, logs / "eyewitness.log", opts.tool_timeout,
                                           verify=tools.verify_eyewitness))

    live = consolidate.parse_eyewitness_db(domain_dir)
    for host, ip in dd.bbot_live.items():  # bbot DNS resolution is live-host evidence too
        live.setdefault(host, ip)
    counts = consolidate.write_files(domain_dir, dd, live_urls=live)
    status_lines = [status_line(r) for r in results]
    consolidate.write_summary(domain_dir, domain, status_lines, counts)
    return results, counts


def main(argv=None) -> int:
    parser = build_parser()
    opts = parser.parse_args(argv)

    if opts.list_tools:
        return list_tools()

    if opts.check is not None:
        requested = [t.strip() for t in opts.check.split(",") if t.strip()] if opts.check else []
        return run_checks(requested)

    if opts.install is not None:
        names = opts.install or list(install.INSTALLERS)
        bad = [n for n in names if n not in install.INSTALLERS]
        if bad:
            parser.error(f"unknown tool(s): {', '.join(bad)}; valid: {', '.join(install.INSTALLERS)}")
        failures = install.install(names)
        tools.record_paths()
        print()
        list_tools()
        return 1 if failures else 0

    enabled = resolve_enabled(opts)
    issues = preflight(enabled)
    if issues:
        print("\nwarnings - these enabled tools are missing/broken and will be skipped:")
        for name, detail in issues:
            print(f"  {name:<10} {detail}")
            print(f"             fix: {tools.TOOL_FIX_HINTS[name]}")
        print()
    opts.enabled_all = enabled
    opts.enabled_passive = {t for t in PASSIVE_TOOLS if t in enabled}

    domains = collect_domains(opts)
    if not domains:
        parser.error("no domains given (positional args or -f FILE)")

    outroot = Path(opts.outdir)
    outroot.mkdir(parents=True, exist_ok=True)

    any_fail = False
    all_skipped = True
    print(f"ept-auto v{VERSION} - domains: {', '.join(domains)}")
    print(f"tools: {', '.join(sorted(enabled))}\n")
    for domain in domains:
        print(f"=== {domain} ===")
        results, counts = run_domain(domain, outroot, opts)
        ran = [r for r in results if r.status != "skipped"]
        if ran:
            all_skipped = False
        if any(r.status == "fail" for r in ran):
            any_fail = True
        print()
        print(f"[{domain}] counts: " + ", ".join(f"{k}={v}" for k, v in sorted(counts.items()) if v))
        print(f"[{domain}] done -> {outroot / domain / 'combined'}\n")

    if opts.consolidate_only:
        return 0
    if all_skipped:
        return 2
    if any_fail:
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
