"""Binary discovery + command builders for every tool EPT-auto drives.

Notable doc-verified behavior baked in here:
- subfinder is passive by design (no -passive flag exists); -o writes results.
- bbot presets: subdomain-enum/email-enum/cloud-enum/web (wappalyzer)/tech-detect.
- waymore -mode U + -oU for URL-only collection; -lr caps requests per source.
- cloud_enum (uv entrypoint `cloud_enum`): -k repeatable, -l FILE -f json for JSONL log.
- EyeWitness (RedSiege fork): runs through its eyewitness-venv python.
"""

from __future__ import annotations

import json
import os
import re
import shlex
import shutil
import subprocess
from pathlib import Path

HOME = Path.home()
EPT_TOOLS_ROOT = HOME / ".local" / "share" / "ept-auto"
CONFIG_DIR = HOME / ".config" / "ept-auto"
CONFIG_FILE = CONFIG_DIR / "tools.json"

DEFAULT_BBOT_PRESETS = "subdomain-enum,email-enum,cloud-enum,web,tech-detect"

TOOL_LABELS = {
    "subfinder": "Subfinder (passive subdomain enumeration)",
    "bbot": "BBOT (subdomains/emails/cloud/apps/tech)",
    "waymore": "waymore (wayback/commoncrawl URL discovery)",
    "cloud_enum": "cloud_enum (AWS/Azure/GCP OSINT)",
    "eyewitness": "EyeWitness (web screenshots + headers)",
}

TOOL_URLS = {
    "subfinder": "https://github.com/projectdiscovery/subfinder",
    "bbot": "https://github.com/blacklanternsecurity/bbot",
    "waymore": "https://github.com/xnl-h4ck3r/waymore",
    "cloud_enum": "https://github.com/initstring/cloud_enum",
    "eyewitness": "https://github.com/RedSiege/EyeWitness",
}

TOOL_FIX_HINTS = {
    "subfinder": "self-installable: ./ept-auto.sh --install subfinder",
    "bbot": "self-installable (large download): ./ept-auto.sh --install bbot; needs sudo on first scan to add system deps (7z/unzip/openssl headers)",
    "waymore": "self-installable: ./ept-auto.sh --install waymore",
    "cloud_enum": "self-installable: ./ept-auto.sh --install cloud_enum",
    "eyewitness": "needs root once: sudo ./ept-auto.sh --install eyewitness (adds chromium/chromedriver/xvfb)",
}


def load_cfg():
    if CONFIG_FILE.exists():
        try:
            return json.loads(CONFIG_FILE.read_text())
        except Exception:
            return {}
    return {}


def save_cfg(cfg):
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.write_text(json.dumps(cfg, indent=2, sort_keys=True) + "\n")


def slug(domain: str) -> str:
    return re.sub(r"[^A-Za-z0-9-]+", "-", domain).strip("-")


def _q(cmd) -> str:
    """Shell-safe rendering of a command list for logs."""
    return " ".join(shlex.quote(str(c)) for c in cmd)


def tool_bin(name: str):
    """Resolve a tool executable: saved config path first, then known spots, then $PATH."""
    configured = load_cfg().get("paths", {}).get(name)
    candidates = []
    if configured:
        candidates.append(Path(configured).expanduser())
    known = {
        "subfinder": [HOME / ".local" / "bin" / "subfinder"],
        "cloud_enum": [HOME / ".local" / "bin" / "cloud_enum"],
    }.get(name, [])
    candidates.extend(known)
    for cand in candidates:
        if cand.is_file() and os.access(str(cand), os.X_OK):
            return str(cand)
    return shutil.which(name)


def cloud_enum_keywords(domain: str, opts) -> list[str]:
    shorthand = domain.rsplit(".", 1)[0]
    keywords = [domain]
    if shorthand and shorthand not in keywords:
        keywords.append(shorthand)
    for extra in getattr(opts, "cloud_keyword", None) or []:
        if extra and extra not in keywords:
            keywords.append(extra)
    return keywords


def build_subfinder(domain, raw, opts):
    bin_ = tool_bin("subfinder")
    if not bin_:
        return None, "not installed (run: ./ept-auto.sh --install subfinder)"
    out = raw / "subfinder" / "subs.txt"
    out.parent.mkdir(parents=True, exist_ok=True)
    cmd = [bin_, "-d", domain, "-max-time", str(opts.subfinder_max_time), "-o", str(out)]
    if opts.subfinder_all:
        cmd.append("-all")
    return cmd, None


def build_bbot(domain, raw, opts, ts):
    bin_ = tool_bin("bbot")
    if not bin_:
        return None, "not installed (run: sudo ./ept-auto.sh --install bbot)"
    presets = [p.strip() for p in opts.bbot_presets.split(",") if p.strip()]
    cmd = [bin_, "-t", domain]
    for preset in presets:
        cmd += ["-p", preset]
    cmd += [
        # -o/--output-dir redirects the scan dir; -y skips the confirmation prompt
        "-o", str(raw / "bbot"),
        "--name", f"ept-{slug(domain)}-{ts}",
        "-y",
    ]
    return cmd, None


def build_waymore(domain, raw, opts, ts):
    bin_ = tool_bin("waymore")
    if not bin_:
        return None, "not installed (run: ./ept-auto.sh --install waymore)"
    out = raw / "waymore" / "waymore.txt"
    out.parent.mkdir(parents=True, exist_ok=True)
    cmd = [
        bin_, "-i", domain,
        "-mode", opts.waymore_mode,
        "-oU", str(out),
        "-lr", str(opts.waymore_limit_requests),
    ]
    if not opts.waymore_append:
        cmd.append("-ow")
    return cmd, None


def build_cloud_enum(domain, raw, opts, ts):
    bin_ = tool_bin("cloud_enum") or tool_bin("cloud_enum.py")
    if not bin_:
        return None, "not installed (run: ./ept-auto.sh --install cloud_enum)"
    run_dir = raw / "cloud_enum" / f"run-{ts}"
    findings = run_dir / "findings.json"
    findings.parent.mkdir(parents=True, exist_ok=True)
    cmd = [bin_]
    for kw in cloud_enum_keywords(domain, opts):
        cmd += ["-k", kw]
    cmd += ["-l", str(findings), "-f", "json", "-t", str(opts.cloud_threads)]
    if opts.cloud_quickscan:
        cmd.append("-qs")
    if opts.cloud_mutations:
        cmd += ["-m", opts.cloud_mutations]
    return cmd, None


def eyewitness_paths():
    root = Path(load_cfg().get("eyewitness_root", str(EPT_TOOLS_ROOT / "EyeWitness")))
    return root, root / "eyewitness-venv" / "bin" / "python", root / "Python" / "EyeWitness.py"


def build_eyewitness(domain, raw, opts):
    urls_file = raw / "urls_for_eyewitness.txt"
    if not urls_file.exists():
        return None, "no url list was generated"
    _, py, script = eyewitness_paths()
    if not (py.exists() and script.exists()):
        return None, "not installed (run: sudo ./setup.sh or ./ept-auto.sh --install eyewitness)"
    threads = opts.eyewitness_threads or min(20, (os.cpu_count() or 2) * 2)
    out_dir = raw / "eyewitness"
    out_dir.mkdir(parents=True, exist_ok=True)
    cmd = [str(py), str(script), "-f", str(urls_file), "-d", str(out_dir), "--threads", str(threads)]
    return cmd, None


def list_status():
    """Return [(name, label, path_or_None)] for all bundled tools."""
    rows = []
    for name, label in TOOL_LABELS.items():
        rows.append((name, label, tool_bin(name)))
    return rows


# flags that prove an executable actually runs (fast, side-effect free)
TOOL_PROBE_FLAGS = {
    "subfinder": ["-version"],
    "bbot": ["--version"],
    "waymore": ["--version"],
    "cloud_enum": ["-h"],
}


def tool_ok(name, timeout=30):
    """Deeper check: execute the tool's version/help command.

    Returns (ok: bool, detail: str). For eyewitness the venv python must exist,
    run, and import selenium.
    """
    if name == "eyewitness":
        _, py, script = eyewitness_paths()
        if not (py.exists() and script.exists()):
            return False, "venv/python or EyeWitness.py missing (run: sudo ./ept-auto.sh --install eyewitness)"
        try:
            proc = subprocess.run(
                [str(py), "-c", "import selenium, argparse"],
                capture_output=True, text=True, timeout=timeout,
            )
        except (OSError, subprocess.TimeoutExpired) as exc:
            return False, f"venv python failed: {exc}"
        if proc.returncode != 0:
            return False, "venv python cannot import selenium (setup incomplete)"
        return True, str(script)
    bin_ = tool_bin(name)
    if not bin_:
        return False, "not found on PATH or in ept-auto config"
    try:
        proc = subprocess.run(
            [bin_, *TOOL_PROBE_FLAGS[name]], capture_output=True, text=True, timeout=timeout
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        return False, f"exists at {bin_} but failed to run: {exc}"
    if proc.returncode != 0:
        detail = (proc.stderr or proc.stdout or "").strip().splitlines()[-1:] or ""
        return False, f"exists at {bin_} but exited rc={proc.returncode} {detail}"
    return True, bin_


def record_paths():
    """Persist discovered tool paths in tools.json so config stays ahead of $PATH."""
    cfg = load_cfg()
    paths = cfg.setdefault("paths", {})
    for name in TOOL_LABELS:
        found = _resolve_only(name)
        if found:
            paths[name] = found
    save_cfg(cfg)
    return paths


def _resolve_only(name: str):
    """Same resolution as tool_bin minus $PATH recursion complexities."""
    configured = load_cfg().get("paths", {}).get(name)
    candidates = []
    if configured:
        candidates.append(Path(configured).expanduser())
    known = {
        "subfinder": [HOME / ".local" / "bin" / "subfinder"],
        "cloud_enum": [HOME / ".local" / "bin" / "cloud_enum"],
    }.get(name, [])
    candidates.extend(known)
    for cand in candidates:
        try:
            if cand.is_file() and os.access(str(cand), os.X_OK):
                return str(cand)
        except OSError:
            continue
    return shutil.which(name)
