"""Binary discovery + command builders for every tool EPT-auto drives.

Notable doc-verified behavior baked in here:
- subfinder is passive by design (no -passive flag exists); -o writes results.
- bbot presets: subdomain-enum/email-enum/cloud-enum/web (wappalyzer)/tech-detect.
- waymore -mode U + -oU for URL-only collection; -lr caps requests per source.
- cloud_enum (uv entrypoint `cloud_enum`): -k repeatable, -l FILE -f json for JSONL log.
- EyeWitness (RedSiege fork): resolved clone-with-venv, Kali system package
  (/usr/share/eyewitness), or the eyewitness/EyeWitness binary on PATH.
"""

from __future__ import annotations

import json
import os
import re
import shlex
import shutil
import subprocess
from datetime import datetime
from pathlib import Path

HOME = Path.home()
EPT_TOOLS_ROOT = HOME / ".local" / "share" / "ept-auto"
CONFIG_DIR = HOME / ".config" / "ept-auto"
CONFIG_FILE = CONFIG_DIR / "tools.json"

DEFAULT_BBOT_PRESETS = "subdomain-enum,email-enum,cloud-enum,web,tech-detect"

TOOL_LABELS = {
    "subfinder": "Subfinder (passive subdomain enumeration)",
    "bbot": "BBOT (subdomains/emails/cloud/apps/tech)",
    "waymore": "waymore (wayback/commoncrawl URL discovery)",
    "cloud_enum": "cloud_enum (AWS/Azure/GCP OSINT)",
    "eyewitness": "EyeWitness (web screenshots + headers)",
}

TOOL_URLS = {
    "subfinder": "https://github.com/projectdiscovery/subfinder",
    "bbot": "https://github.com/blacklanternsecurity/bbot",
    "waymore": "https://github.com/xnl-h4ck3r/waymore",
    "cloud_enum": "https://github.com/initstring/cloud_enum",
    "eyewitness": "https://github.com/RedSiege/EyeWitness",
}

TOOL_FIX_HINTS = {
    "subfinder": "self-installable: ./ept-auto.sh --install subfinder",
    "bbot": "self-installable (large download): ./ept-auto.sh --install bbot (pipx or uv); needs sudo on first scan to add system deps (7z/unzip/openssl headers)",
    "waymore": "self-installable: ./ept-auto.sh --install waymore (pipx or uv)",
    "cloud_enum": "self-installable: ./ept-auto.sh --install cloud_enum (pipx or uv)",
    "eyewitness": "on Kali: sudo apt install -y eyewitness; else sudo ./ept-auto.sh --install eyewitness (adds chromium/chromedriver/xvfb)",
}


def load_cfg():
    if CONFIG_FILE.exists():
        try:
            return json.loads(CONFIG_FILE.read_text())
        except Exception:
            return {}
    return {}


def save_cfg(cfg):
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.write_text(json.dumps(cfg, indent=2, sort_keys=True) + "\n")


def slug(domain: str) -> str:
    return re.sub(r"[^A-Za-z0-9-]+", "-", domain).strip("-")


def _q(cmd) -> str:
    """Shell-safe rendering of a command list for logs."""
    return " ".join(shlex.quote(str(c)) for c in cmd)


def tool_bin(name: str):
    """Resolve a tool executable: saved config path first, then known spots, then $PATH."""
    configured = load_cfg().get("paths", {}).get(name)
    candidates = []
    if configured:
        candidates.append(Path(configured).expanduser())
    known = {
        "subfinder": [HOME / ".local" / "bin" / "subfinder"],
        "cloud_enum": [HOME / ".local" / "bin" / "cloud_enum"],
    }.get(name, [])
    candidates.extend(known)
    for cand in candidates:
        if cand.is_file() and os.access(str(cand), os.X_OK):
            return str(cand)
    return shutil.which(name)


def cloud_enum_keywords(domain: str, opts) -> list[str]:
    shorthand = domain.rsplit(".", 1)[0]
    keywords = [domain]
    if shorthand and shorthand not in keywords:
        keywords.append(shorthand)
    for extra in getattr(opts, "cloud_keyword", None) or []:
        if extra and extra not in keywords:
            keywords.append(extra)
    return keywords


def build_subfinder(domain, raw, opts):
    bin_ = tool_bin("subfinder")
    if not bin_:
        return None, "not installed (run: ./ept-auto.sh --install subfinder)"
    out = raw / "subfinder" / "subs.txt"
    out.parent.mkdir(parents=True, exist_ok=True)
    cmd = [bin_, "-d", domain, "-max-time", str(opts.subfinder_max_time), "-o", str(out)]
    if opts.subfinder_all:
        cmd.append("-all")
    return cmd, None


def build_bbot(domain, raw, opts, ts):
    bin_ = tool_bin("bbot")
    if not bin_:
        return None, "not installed (run: sudo ./ept-auto.sh --install bbot)"
    presets = [p.strip() for p in opts.bbot_presets.split(",") if p.strip()]
    cmd = [bin_, "-t", domain]
    for preset in presets:
        cmd += ["-p", preset]
    cmd += [
        # -o/--output-dir redirects the scan dir; -y skips the confirmation prompt
        "-o", str(raw / "bbot"),
        "--name", f"ept-{slug(domain)}-{ts}",
        "-y",
    ]
    return cmd, None


def build_waymore(domain, raw, opts, ts):
    bin_ = tool_bin("waymore")
    if not bin_:
        return None, "not installed (run: ./ept-auto.sh --install waymore)"
    out = raw / "waymore" / "waymore.txt"
    out.parent.mkdir(parents=True, exist_ok=True)
    cmd = [
        bin_, "-i", domain,
        "-mode", opts.waymore_mode,
        "-oU", str(out),
        "-lr", str(opts.waymore_limit_requests),
    ]
    if not opts.waymore_append:
        cmd.append("-ow")
    return cmd, None


def build_cloud_enum(domain, raw, opts, ts):
    bin_ = tool_bin("cloud_enum") or tool_bin("cloud_enum.py")
    if not bin_:
        return None, "not installed (run: ./ept-auto.sh --install cloud_enum)"
    run_dir = raw / "cloud_enum" / f"run-{ts}"
    findings = run_dir / "findings.json"
    findings.parent.mkdir(parents=True, exist_ok=True)
    cmd = [bin_]
    for kw in cloud_enum_keywords(domain, opts):
        cmd += ["-k", kw]
    cmd += ["-l", str(findings), "-f", "json", "-t", str(opts.cloud_threads)]
    if opts.cloud_quickscan:
        cmd.append("-qs")
    if opts.cloud_mutations:
        cmd += ["-m", opts.cloud_mutations]
    return cmd, None


def eyewitness_location():
    """Resolve EyeWitness in priority order:

      1. recorded clone (cfg eyewitness_root + eyewitness-venv)             -> mode "clone"
      2. Kali/Debian system package (/usr/share/eyewitness[ eyewitness])    -> mode "system"
      3. eyewitness/EyeWitness binary on PATH                               -> mode "bin"

    Returns dict with mode + exec parts, or None (caller shows requirement hint).
    """
    cfg = load_cfg()
    root = Path(cfg.get("eyewitness_root") or (EPT_TOOLS_ROOT / "EyeWitness"))
    venv_py = root / "eyewitness-venv" / "bin" / "python"
    root_script = root / "Python" / "EyeWitness.py"
    if venv_py.exists() and root_script.exists():
        return {"mode": "clone", "root": str(root), "python": str(venv_py), "script": str(root_script)}
    for base in ("/usr/share/eyewitness", "/usr/share/EyeWitness"):
        system_script = Path(base) / "Python" / "EyeWitness.py"
        if system_script.exists():
            python3 = tool_bin("python3")
            if python3:
                return {"mode": "system", "root": base, "python": python3, "script": str(system_script)}
    for exe in ("eyewitness", "EyeWitness"):
        bin_ = shutil.which(exe)
        if bin_:
            return {"mode": "bin", "root": bin_, "python": bin_, "script": ""}
    return None


def eyewitness_requirement() -> str:
    return (
        "EyeWitness not found. On Kali: sudo apt install -y eyewitness (system package),"
        " or sudo ./ept-auto.sh --install eyewitness (clone into ept-auto tools dir)"
    )


def _eyewitness_cmd(loc, urls_file, run_dir, threads):
    exec_head = [loc["python"]]
    if loc.get("script"):
        exec_head.append(loc["script"])
    return [*exec_head, "-f", str(urls_file), "-d", str(run_dir), "--threads", str(threads)]


def build_eyewitness(domain, raw, opts):
    urls_file = raw / "urls_for_eyewitness.txt"
    if not urls_file.exists():
        return None, "no url list was generated"
    loc = eyewitness_location()
    if not loc:
        return None, eyewitness_requirement()
    threads = opts.eyewitness_threads or min(20, (os.cpu_count() or 2) * 2)
    # per-run dir: EyeWitness asks interactively to overwrite existing dirs,
    # which hangs under ept-auto's non-interactive stdin
    run_dir = raw / "eyewitness" / f"run-{datetime.now().strftime('%Y%m%d-%H%M%S')}"
    run_dir.mkdir(parents=True, exist_ok=True)
    cmd = _eyewitness_cmd(loc, urls_file, run_dir, threads)
    return cmd, None


def verify_bbot(cmd) -> tuple[bool, str]:
    """rc=0 is not enough: bbot aborts with rc 0 (e.g. on failed module deps)."""
    try:
        out_dir = Path(cmd[cmd.index("-o") + 1])
        name = cmd[cmd.index("--name") + 1]
    except (ValueError, IndexError):
        return False, "could not determine bbot scan output dir"
    produced = (out_dir / name / "output.json").exists()
    reason = "" if produced else "ran but produced no scan output (module deps failed? see the bbot log)"
    return produced, reason


def verify_eyewitness(cmd) -> tuple[bool, str]:
    try:
        run_dir = Path(cmd[cmd.index("-d") + 1])
    except (ValueError, IndexError):
        return False, "could not determine eyewitness output dir"
    ok = (run_dir / "ew.db").exists()
    return ok, "" if ok else "ran but produced no ew.db (see the eyewitness log)"


def list_status():
    """Return [(name, label, path_or_None)] for all bundled tools."""
    rows = []
    for name, label in TOOL_LABELS.items():
        rows.append((name, label, tool_bin(name)))
    return rows


# flags that prove an executable actually runs (fast, side-effect free)
TOOL_PROBE_FLAGS = {
    "subfinder": ["-version"],
    "bbot": ["--version"],
    "waymore": ["--version"],
    "cloud_enum": ["-h"],
}


def _eyewitness_probe(loc, timeout=180) -> tuple[bool, str]:
    """Run a 1-URL EyeWitness capture (port deliberately closed) to prove the
    chromium/driver stack works; ew.db existing is the success signal."""
    import tempfile

    try:
        td = tempfile.TemporaryDirectory(prefix="ept-ew-check-", dir="/tmp/opencode")
    except (OSError, FileNotFoundError):
        td = tempfile.TemporaryDirectory(prefix="ept-ew-check-")
    with td as tmp:
        tmp = Path(tmp)
        urls = tmp / "probe-urls.txt"
        urls.write_text("http://127.0.0.1:9\n")  # discard port: instant refusal, driver still launches
        outdir = tmp / "probe-run"
        stdin = subprocess.DEVNULL
        try:
            proc = subprocess.run(
                _eyewitness_cmd(loc, urls, outdir, 2),
                input=None, stdin=stdin, capture_output=True, text=True, timeout=timeout,
            )
        except (OSError, subprocess.TimeoutExpired) as exc:
            return False, f"eyewitness probe failed to run: {exc}"
        if (outdir / "ew.db").exists():
            return True, loc.get("root") or "unknown install"
        burst = ((proc.stderr or "") + (proc.stdout or "")).strip().splitlines()
        tail = " | ".join(x.strip() for x in burst[-6:] if x.strip())
        if not tail:
            tail = f"rc={proc.returncode}"
        return False, f"probe run produced no ew.db: {tail[-600:]}"


def tool_ok(name, timeout=30):
    """Deeper check: execute the tool's version/help command.

    Returns (ok: bool, detail: str). For eyewitness the located install's python
    must import selenium, then a live probe proves chromium/chromedriver work.
    """
    if name == "eyewitness":
        loc = eyewitness_location()
        if not loc:
            return False, eyewitness_requirement()
        if loc["mode"] != "bin":
            try:
                proc = subprocess.run(
                    [loc["python"], "-c", "import selenium, argparse"],
                    capture_output=True, text=True, timeout=timeout,
                )
            except (OSError, subprocess.TimeoutExpired) as exc:
                return False, f"{loc['mode']} python failed: {exc}"
            if proc.returncode != 0:
                return False, f"{loc['mode']} python cannot import selenium (deps not installed)"
        # structural check passed; now prove chromium+chromedriver can actually screenshot
        return _eyewitness_probe(loc)

    bin_ = tool_bin(name)
    if not bin_:
        return False, "not found on PATH or in ept-auto config"
    try:
        proc = subprocess.run(
            [bin_, *TOOL_PROBE_FLAGS[name]], capture_output=True, text=True, timeout=timeout
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        return False, f"exists at {bin_} but failed to run: {exc}"
    if proc.returncode != 0:
        detail = (proc.stderr or proc.stdout or "").strip().splitlines()[-1:] or ""
        return False, f"exists at {bin_} but exited rc={proc.returncode} {detail}"
    return True, bin_


def record_paths():
    """Persist discovered tool paths in tools.json so config stays ahead of $PATH."""
    cfg = load_cfg()
    paths = cfg.setdefault("paths", {})
    for name in TOOL_LABELS:
        found = _resolve_only(name)
        if found:
            paths[name] = found
    save_cfg(cfg)
    return paths


def _resolve_only(name: str):
    """Same resolution as tool_bin minus $PATH recursion complexities."""
    configured = load_cfg().get("paths", {}).get(name)
    candidates = []
    if configured:
        candidates.append(Path(configured).expanduser())
    known = {
        "subfinder": [HOME / ".local" / "bin" / "subfinder"],
        "cloud_enum": [HOME / ".local" / "bin" / "cloud_enum"],
    }.get(name, [])
    candidates.extend(known)
    for cand in candidates:
        try:
            if cand.is_file() and os.access(str(cand), os.X_OK):
                return str(cand)
        except OSError:
            continue
    return shutil.which(name)
