"""Consolidates raw tool output for a domain into clean combined/*.txt lists."""

from __future__ import annotations

import json
import re
import sqlite3
from datetime import datetime
from pathlib import Path
from urllib.parse import urlsplit

EMAIL_RE = re.compile(r"[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}")


def read_text(path: Path) -> str:
    try:
        return Path(path).read_text(errors="replace")
    except OSError:
        return ""


class DomainData:
    def __init__(self, domain: str):
        self.domain = domain
        self.subdomains: set[str] = set()
        self.urls: set[str] = set()
        self.emails: set[str] = set()
        self.apps: set[str] = set()
        self.cloud: set[str] = set()
        self.findings: set[str] = set()
        self.code_repos: set[str] = set()
        self.ports: set[str] = set()
        self.usernames_social: set[tuple[str, str]] = set()  # (platform, handle)
        self.bbot_live: dict[str, str] = {}  # host -> ip (from DNS_NAME events with resolved hosts)

    def add_sub(self, host: str):
        host = (host or "").strip().lower().rstrip(".")
        host = host.split("://")[-1].split("/")[0].split("@")[-1].split(":")[0]
        if host == self.domain or host.endswith("." + self.domain):
            self.subdomains.add(host)

    def add_url(self, url: str):
        url = (url or "").strip().split("#", 1)[0]
        if not url or "://" not in url:
            return
        try:
            parts = urlsplit(url)
        except ValueError:
            return
        host = (parts.netloc or "").lower().split("@")[-1].split(":")[0].rstrip(".")
        if host == self.domain or host.endswith("." + self.domain):
            self.urls.add(url)

    def add_email(self, email: str):
        email = (email or "").strip().lower()
        if email.count("@") != 1:
            return
        host = email.split("@", 1)[1].rstrip(".")
        if host == self.domain or host.endswith("." + self.domain):
            self.emails.add(email)

    def scan_text(self, text: str):
        for match in EMAIL_RE.finditer(text or ""):
            self.add_email(match.group(0))

    @property
    def usernames(self) -> set[str]:
        users = set()
        for email in self.emails:
            users.add(email.split("@", 1)[0])
        return users


def parse_subfinder(raw: Path, dd: DomainData):
    for line in read_text(raw / "subfinder" / "subs.txt").splitlines():
        if line.strip():
            dd.add_sub(line)


def _pretty_finding(src: dict) -> str:
    """bbot FINDING/VULNERABILITY data dict: severity/confidence/name/description/url/cves."""
    sev = str(src.get("severity") or "INFO").upper()
    conf = str(src.get("confidence") or "UNKNOWN").upper()
    name = str(src.get("name") or "").strip()
    desc = str(src.get("description") or src.get("message") or "").strip()
    url = str(src.get("url") or src.get("full_url") or src.get("host") or "").strip()
    cves = src.get("cves") or []
    parts = [f"[{sev}/{conf}]", name]
    if url:
        parts.append(url)
    if name and desc:
        parts.append("- " + desc)
    if cves:
        parts.append("(" + ", ".join(str(c) for c in cves) + ")")
    return " ".join(p for p in parts if p).strip()


def parse_bbot(raw: Path, dd: DomainData):
    """bbot JSONL event families (src: core/event/base.py):

      DNS_NAME* (DnsEvent)          data str, live when resolved_hosts has IPv4
      URL*/HTTP_RESPONSE/URL_HINT   data str, or dict with 'url'
      EMAIL_ADDRESS                 data str
      OPEN_TCP_PORT/OPEN_UDP_PORT   {host, port} - only trusted scanner modules
      VIRTUAL_HOST                  {host, url, ...}
      STORAGE_BUCKET(+HOSTNAME/NAME){url, host} or str - cloud findings
      AZURE_TENANT                  {tenant-id, tenant-names, domains?}
      MOBILE_APP                    {url, id}
      CODE_REPOSITORY(+UNFORMED)    {url} or str
      TECHNOLOGY                    {host, technology, url?} or str
      WAF / WAF_BLOCK_PAGE          {url, host, waf, info?}
      SOCIAL                        {platform, profile_name, url}
      USERNAME / PASSWORD           data str - credential sightings
      FINDING / VULNERABILITY       {severity, confidence, name, description, url?, cves?}
    Internal/misc events (SCAN, TAG, ERROR, WEB_PARAMETER, RAW_DNS_RECORD, ASN,
    GEOLOCATION, HTTP_RESPONSE bodies, ORG_STUB, PROTOCOL...) are ignored.
    """
    ipv4 = re.compile(r"^(\d{1,3}\.){3}\d{1,3}$")
    port_modules = {"portscan", "fingerprintx", "shodan-ip", "censys-ip", "cerll"}
    for js in sorted(raw.glob("bbot/**/output.json")):
        for line in read_text(js).splitlines():
            line = line.strip()
            if not line.startswith("{"):
                continue
            try:
                obj = json.loads(line)
            except ValueError:
                continue
            if not isinstance(obj, dict):
                continue
            ev = obj.get("type", "") or ""
            module = str(obj.get("module") or "")
            data = obj.get("data")
            dj = obj.get("data_json") if isinstance(obj.get("data_json"), dict) else {}

            def d_val(key):
                if isinstance(data, dict):
                    v = data.get(key)
                    if not v and dj:
                        v = dj.get(key)
                elif dj:
                    v = dj.get(key)
                else:
                    v = None
                return v

            if ev.startswith("DNS_NAME"):
                if isinstance(data, str) and data:
                    dd.add_sub(data)
                    if live_resolved := [h for h in (obj.get("resolved_hosts") or []) if ipv4.fullmatch(str(h))]:
                        if not data.startswith("*."):
                            dd.bbot_live[data.lower()] = ",".join(sorted(live_resolved)[:2])
            elif ev.startswith("URL"):
                url = data if isinstance(data, str) else d_val("url")
                if isinstance(url, str) and url:
                    dd.add_url(url)
            elif ev == "EMAIL_ADDRESS":
                email = data if isinstance(data, str) else (dj.get("email") if dj else None)
                if isinstance(email, str) and email:
                    dd.add_email(email)
            elif ev.startswith("OPEN_TCP_PORT") or ev.startswith("OPEN_UDP_PORT"):
                host = d_val("host") or (data if isinstance(data, str) else "")
                port = d_val("port")
                if module in port_modules and host and isinstance(port, (int, str)):
                    entry = f"{str(host).strip()}:{port}".replace(":::", "")
                    if entry.count(":") <= 1:
                        dd.ports.add(entry)
            elif ev == "VIRTUAL_HOST":
                if url := d_val("url"):
                    if isinstance(url, str) and url:
                        dd.add_url(url)
                if isinstance(data, str) and data:  # UNFORMED
                    dd.add_sub(data)
            elif ev.startswith("STORAGE_BUCKET"):
                url = data if isinstance(data, str) else d_val("url")
                if isinstance(url, str) and url:
                    dd.cloud.add(url.strip())
                elif isinstance(data, str):
                    dd.cloud.add(data.strip())
            elif ev == "AZURE_TENANT":
                names = [str(x) for x in dj.get("tenant-names", []) if x]
                tenant = str(dj.get("tenant-id") or "")
                doms = [str(x) for x in dj.get("domains", []) if x]
                dd.cloud.add("microsoft-tenant\t" + "\t".join(filter(None, [tenant, *names, *doms])))
            elif ev == "MOBILE_APP":
                app_id = d_val("id")
                url = d_val("url")
                label = (str(app_id) if app_id else "") + ((f" ({url})" if url else "") if isinstance(url, str) else "")
                if label.strip():
                    dd.apps.add(f"mobile-app: {label.strip()}")
            elif ev.startswith("CODE_REPOSITORY") or ev.startswith("CODE_ISSUE"):
                url = data if isinstance(data, str) else d_val("url")
                if isinstance(url, str) and url:
                    dd.code_repos.add(url.strip())
            elif ev == "TECHNOLOGY":
                payload = data if isinstance(data, dict) else (dj or data)
                if isinstance(payload, dict):
                    tech = str(payload.get("technology") or payload.get("app") or payload.get("host") or "").strip()
                    host = str(payload.get("host") or payload.get("url") or "").strip()
                    if tech:
                        dd.apps.add(f"{tech} - {host}" if host else tech)
                elif isinstance(payload, str) and payload.strip():
                    dd.apps.add(payload.strip())
            elif ev == "WAF" or ev == "WAF_BLOCK_PAGE":
                waf = d_val("waf")
                url = d_val("url")
                if isinstance(waf, str) and waf:
                    dd.apps.add(f"WAF: {waf}" + (f" - {url}" if isinstance(url, str) and url else ""))
            elif ev == "SOCIAL":
                platform = str(dj.get("platform") or (data.get("platform") if isinstance(data, dict) else "") or "")
                profile = str(dj.get("profile_name") or (data.get("profile_name") if isinstance(data, dict) else "") or "")
                if profile and " " not in profile:
                    dd.usernames_social.add((platform, profile.lower()))
            elif ev == "USERNAME" and isinstance(data, str) and data:
                dd.usernames_social.add(("", data.lower()))
            elif ev.startswith(("PASSWORD", "HASHED_PASSWORD")) and isinstance(data, str) and data:
                dd.findings.add(f"[CREDENTIAL] {module}: {data}")
            elif ev in ("FINDING", "VULNERABILITY"):
                pretty = _pretty_finding(dj or (data if isinstance(data, dict) else {}))
                dd.findings.add(pretty or line)


def parse_waymore(raw: Path, dd: DomainData):
    userinfo = re.compile(r"(?i)(?<=://)[^/@\s]+@")
    for line in read_text(raw / "waymore" / "waymore.txt").splitlines():
        url = line.strip()
        if not url or "://" not in url:
            continue
        dd.add_url(url)
        dd.scan_text(userinfo.sub("", url))


def parse_cloud_enum(raw: Path, dd: DomainData):
    base = raw / "cloud_enum"
    if not base.exists():
        return
    for run_dir in sorted((p for p in base.iterdir() if p.is_dir()), key=lambda p: p.name):
        for line in read_text(run_dir / "findings.json").splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            obj = None
            if line.startswith("{"):
                try:
                    obj = json.loads(line)
                except ValueError:
                    obj = None
            if isinstance(obj, dict):
                target = str(obj.get("target") or obj.get("url") or "")
                msg = str(obj.get("msg") or obj.get("service") or "")
                access = str(obj.get("access") or "")
                dd.cloud.add("\t".join(x for x in (target, access, msg) if x))
                dd.scan_text(target + " " + msg)
            else:
                dd.cloud.add(line)


def consolidate_raw(domain: str, domain_dir: Path) -> DomainData:
    raw = domain_dir / "raw"
    dd = DomainData(domain)
    dd.add_sub(domain)  # keep the base domain in the list
    parse_subfinder(raw, dd)
    parse_bbot(raw, dd)
    parse_waymore(raw, dd)
    parse_cloud_enum(raw, dd)
    return dd


PROFILE_HOSTS = {
    "github.com", "www.github.com",
    "twitter.com", "www.twitter.com", "x.com",
    "medium.com", "www.medium.com",
    "gitlab.com", "www.gitlab.com",
    "linkedin.com", "www.linkedin.com",
    "reddit.com", "www.reddit.com",
    "facebook.com", "www.facebook.com",
}


def usernames_from_waymore_urls(urls):
    """Pull handles only from obvious social/profile URLs (avoids false positives)."""
    users = set()
    for url in urls:
        try:
            parts = urlsplit(url)
            path = parts.path.strip("/")
        except ValueError:
            continue
        if parts.netloc.lower() not in PROFILE_HOSTS:
            continue
        if path and "/" not in path and len(path) < 40:
            users.add(path.lower())
    return users


def build_probe_list(dd: DomainData, limit: int) -> list[str]:
    urls = []
    for host in sorted(dd.subdomains, key=str.lower):
        urls.append(f"https://{host}")
        urls.append(f"http://{host}")
    return urls[: max(0, int(limit))]


def eyewitness_run_dirs(domain_dir: Path) -> list[Path]:
    """All raw/eyewitness/run-* dirs holding an ew.db, newest first (legacy flat dir last)."""
    base = domain_dir / "raw" / "eyewitness"
    if not base.exists():
        return []
    runs = [p for p in base.iterdir() if p.is_dir() and (p / "ew.db").exists()]
    runs.sort(key=lambda p: (p.stat().st_mtime, p.name), reverse=True)
    return runs


def parse_eyewitness_db(domain_dir: Path) -> dict[str, object]:
    """Heuristic SQL over EyeWitness's ew.db: cols holding url/status/screenshot."""
    db = None
    runs = eyewitness_run_dirs(domain_dir)
    if runs:
        db = runs[0] / "ew.db"
    elif (domain_dir / "raw" / "eyewitness" / "ew.db").exists():
        db = domain_dir / "raw" / "eyewitness" / "ew.db"
    if not db:
        return {}
    live = {}
    try:
        con = sqlite3.connect(str(db))
    except sqlite3.Error:
        return {}
    try:
        tables = [r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")]
        for table in tables:
            if table.startswith("sqlite_"):
                continue
            cols = [r[1] for r in con.execute(f'PRAGMA table_info("{table}")')]
            low = {c.lower(): c for c in cols}
            url_col = next((low[k] for k in ("url", "uri", "request") if k in low), None)
            if not url_col:
                continue
            status_col = next((low[k] for k in ("statuscode", "status", "http_status", "httpstatus") if k in low), None)
            screen_col = next((low[k] for k in ("screenshot", "screen", "has_screen", "parsed") if k in low), None)
            select = [url_col]
            if screen_col:
                select.append(screen_col)
            if status_col:
                select.append(status_col)
            query = 'SELECT ' + ", ".join(f'"{c}"' for c in select) + f' FROM "{table}"'
            for row in con.execute(query):
                url = row[0]
                screen = row[1] if screen_col else None
                status = row[-1] if status_col else None
                truthy = screen not in (None, "", 0, "0", "None")
                ok_status = isinstance(status, int) and 200 <= status < 400
                if truthy or ok_status:
                    live[str(url)] = status
    except sqlite3.Error:
        pass
    finally:
        con.close()
    return live


def count_screenshots(domain_dir: Path) -> int:
    runs = eyewitness_run_dirs(domain_dir)
    for run in runs:
        n = len(list(run.glob("screens/*.png")))
        if n:
            return n
    return len(list((domain_dir / "raw" / "eyewitness" / "screens").glob("*.png")))


def write_files(domain_dir: Path, dd: DomainData, live_urls=None) -> dict[str, int]:
    combined = domain_dir / "combined"
    combined.mkdir(parents=True, exist_ok=True)
    counts = {}

    def wfile(name, lines):
        path = combined / name
        path.write_text("\n".join(lines) + ("\n" if lines else ""))
        return len(lines)

    counts["subdomains"] = wfile("subdomains.txt", sorted(dd.subdomains, key=str.lower))
    counts["emails"] = wfile("emails.txt", sorted(dd.emails, key=str.lower))
    users = set(dd.usernames)
    users |= usernames_from_waymore_urls(dd.urls)
    users |= {handle for _, handle in dd.usernames_social}
    counts["usernames"] = wfile("usernames.txt", sorted(users, key=str.lower))
    counts["urls"] = wfile("urls.txt", sorted(dd.urls, key=str.lower))
    counts["apps"] = wfile("apps.txt", sorted(dd.apps))
    counts["cloud_findings"] = wfile("cloud_findings.txt", sorted(dd.cloud))
    counts["code_repos"] = wfile("code_repos.txt", sorted(dd.code_repos, key=str.lower))
    counts["ports"] = wfile("ports.txt", sorted(dd.ports))
    counts["findings"] = wfile("bbot_findings.txt", sorted(dd.findings))

    live = live_urls or {}
    lines = []
    for url, status in sorted(live.items(), key=lambda kv: str(kv[0]).lower()):
        lines.append(url if status is None else f"{url}\t{status}")
    counts["live_hosts"] = wfile("live_hosts.txt", lines)
    counts["screenshots"] = count_screenshots(domain_dir)
    return counts


def write_summary(domain_dir: Path, domain: str, status_lines, counts: dict) -> str:
    d = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    lines = [
        f"ept-auto summary - {domain}",
        f"generated: {d}",
        "",
        "-- tool status --",
    ]
    lines.extend(status_lines or ["  (no tools ran)"])
    lines += ["", "-- consolidated counts --"]
    lines += [f"  {k:<15} {v}" for k, v in sorted(counts.items())]
    combined = domain_dir / "combined"
    lines += ["", "-- output files --"]
    for p in sorted(combined.glob("*.txt")):
        if p.name != "summary.txt":
            lines.append(f"  {p}")
    runs = eyewitness_run_dirs(domain_dir)
    base_ew = domain_dir / "raw" / "eyewitness"
    if runs:
        report = runs[0] / "report.html"
    else:
        report = base_ew / "report.html"
    if report.exists():
        lines.append(f"  {report}")
    text = "\n".join(lines) + "\n"
    (domain_dir / "combined" / "summary.txt").write_text(text)
    return text
