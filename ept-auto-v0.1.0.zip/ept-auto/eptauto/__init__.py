"""EPT-auto: fire five perimeter recon tools at a domain, get clean lists back."""

__VERSION__ = "0.1.0"
