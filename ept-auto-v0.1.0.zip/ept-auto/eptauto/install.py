"""Installer for the five bundled tools.

Python tools (bbot, waymore, cloud_enum) install with pipx when present,
otherwise via `uv tool install` — either way they land in isolated venvs
with executables on ~/.local/bin. subfinder uses the GitHub release binary
(falls back to `go install`). EyeWitness is cloned and bundled setup.sh run
with sudo (installs Chromium/chromedriver/xvfb).
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
import urllib.request
import zipfile
from pathlib import Path

from . import tools

BIN_DIR = Path.home() / ".local" / "bin"


def sh(cmd, cwd=None) -> bool:
    print("  $", " ".join(str(c) for c in cmd))
    rc = subprocess.call(cmd, cwd=cwd)
    return rc == 0


def _download(url, dest: Path) -> bool:
    try:
        with urllib.request.urlopen(url, timeout=120) as resp, open(dest, "wb") as fh:
            fh.write(resp.read())
        return True
    except OSError as exc:
        print(f"  !! download failed: {exc}")
        return False


def _pip_install(packages) -> bool:
    if subprocess.run([sys.executable, "-m", "pip", "--version"], capture_output=True).returncode != 0:
        subprocess.run([sys.executable, "-m", "ensurepip", "--user"], capture_output=True)
    attempts = [
        [sys.executable, "-m", "pip", "install", "--user", "--upgrade", *packages],
        [sys.executable, "-m", "pip", "install", "--user", "--break-system-packages", "--upgrade", *packages],
    ]
    for cmd in attempts:
        proc = subprocess.run(cmd, capture_output=True, text=True)
        if proc.returncode == 0:
            return True
        if "externally-managed" not in (proc.stderr or ""):
            break
    return False


def ensure_uv() -> bool:
    """uv provides isolated python tool installs (bbot/waymore/cloud_enum)."""
    if tools.tool_bin("uv"):
        return True
    print("==> installing uv")
    bin_uv = BIN_DIR / "uv"

    try:
        with urllib.request.urlopen("https://astral.sh/uv/install.sh", timeout=60) as resp:
            script = resp.read()
    except OSError as exc:
        script = b""
        print(f"  astral.sh installer unavailable ({exc}); falling back to pip")

    if script:
        proc = subprocess.run(["bash"], input=script, capture_output=True)
        if proc.returncode == 0 or subprocess.run(["sh"], input=script, capture_output=True).returncode == 0:
            if bin_uv.exists() or shutil.which("uv"):
                print(f"  uv installed: {bin_uv if bin_uv.exists() else shutil.which('uv')}")
                return True
        print("  uv shell installer failed; falling back to pip")

    if not _pip_install(["uv"]):
        print("  !! could not install uv via astral.sh or pip")
        return False
    if bin_uv.exists() or shutil.which("uv"):
        return True
    import sysconfig
    user_scripts = Path(sysconfig.get_path("scripts", f"{os.name}_user") or "")
    for cand in (user_scripts / "uv", user_scripts / "uv.exe"):
        if cand.exists():
            return True
    print("  !! uv pip install finished but no uv executable found on PATH")
    return False


def py_tool_install(spec, name) -> bool:
    """pipx-first (matches what many operators already have), uv fallback."""
    if tools.tool_bin(name):
        print(f"  {name} already installed: {tools.tool_bin(name)} (skipping)")
        return True
    pipx = tools.tool_bin("pipx")
    if pipx:
        return sh([str(pipx), "install", spec])
    if tools.tool_bin("uv") or ensure_uv():
        uv = tools.tool_bin("uv") or (BIN_DIR / "uv")
        return sh([str(uv), "tool", "install", spec])
    print("  !! neither pipx nor uv available to install " + name)
    return False


def install_bbot() -> bool:
    ok = py_tool_install("bbot", "bbot")
    if ok:
        print("  note: bbot installs its own system deps on first scan")
        print("        (it prompts for sudo; run ept-auto with sudo so that succeeds non-interactively)")
    return ok


def install_waymore() -> bool:
    ok = py_tool_install("git+https://github.com/xnl-h4ck3r/waymore.git", "waymore")
    if ok:
        print("  hint: put a urlscan.io API key in ~/.config/waymore/config.yml for best results")
    return ok


def install_cloud_enum() -> bool:
    return py_tool_install("git+https://github.com/initstring/cloud_enum", "cloud_enum")


def install_subfinder() -> bool:
    if tools.tool_bin("subfinder"):
        print(f"  subfinder already installed: {tools.tool_bin('subfinder')} (skipping)")
        return True
    BIN_DIR.mkdir(parents=True, exist_ok=True)
    dest = BIN_DIR / "subfinder"
    print("==> downloading latest subfinder release binary")
    try:
        with urllib.request.urlopen(
            "https://api.github.com/repos/projectdiscovery/subfinder/releases/latest", timeout=60
        ) as resp:
            release = json.loads(resp.read())
    except (OSError, ValueError) as exc:
        print(f"  !! release lookup failed: {exc}")
        release = {"assets": []}
    zip_dest = Path("/tmp/opencode/subfinder.zip")
    zip_dest.parent.mkdir(parents=True, exist_ok=True)
    got_asset = False
    for asset in release.get("assets", []):
        name = asset.get("name", "")
        if "linux_amd64" in name and name.endswith(".zip"):
            if _download(asset.get("browser_download_url", ""), zip_dest):
                got_asset = True
            break
    if got_asset:
        with zipfile.ZipFile(zip_dest) as zf:
            for member in zf.namelist():
                if Path(member).name == "subfinder":
                    with zf.open(member) as src, open(dest, "wb") as fh:
                        fh.write(src.read())
                    dest.chmod(0o755)
                    print(f"  subfinder -> {dest}")
                    return True
        print("  !! subfinder binary not found inside release zip")
    print("  fallback: building from source requires go1.26+")
    return sh(["go", "install", "-v", "github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest"])


def install_eyewitness() -> bool:
    # 1) already present (Kali system package / prior clone / PATH binary)?
    loc = tools.eyewitness_location()
    if loc:
        print(f"  found existing EyeWitness ({loc['mode']}): {loc['root']}")
        cfg = tools.load_cfg()
        if loc["mode"] == "clone":
            cfg["eyewitness_root"] = loc["root"]
            tools.save_cfg(cfg)
        return True

    # 2) else clone + run upstream setup (needs root for chromium/chromedriver/xvfb)
    root = tools.EPT_TOOLS_ROOT / "EyeWitness"
    if os.geteuid() != 0:
        sudo_ok = subprocess.run(["sudo", "-n", "true"], capture_output=True).returncode == 0
        if not sudo_ok and not root.joinpath("eyewitness-venv").exists():
            print("  !! EyeWitness setup needs root: passwordless sudo unavailable")
            print("  requirements:")
            print("    1) git clone https://github.com/RedSiege/EyeWitness.git " + str(root))
            print("    2) cd " + str(root / "setup") + " && sudo bash ./setup.sh")
            print("       (installs chromium + chromedriver + xvfb, creates eyewitness-venv)")
            print("    3) re-run ./ept-auto.sh --install eyewitness (records the path)")
            return False
    if not root.exists():
        root.parent.mkdir(parents=True, exist_ok=True)
        if not sh(["git", "clone", "--depth", "1", "https://github.com/RedSiege/EyeWitness.git", str(root)]):
            return False
    venv = root / "eyewitness-venv"
    if not venv.exists():
        setup_dir = root / "setup"
        if not setup_dir.exists():
            print(f"  !! setup script dir missing under {root}")
            return False
        install_cmd = ["bash", "./setup.sh"] if os.geteuid() == 0 else ["sudo", "bash", "./setup.sh"]
        print("  EyeWitness setup installs Chromium/chromedriver/xvfb and may take a while (needs sudo)")
        if not sh(install_cmd, cwd=setup_dir):
            return False
    cfg = tools.load_cfg()
    cfg["eyewitness_root"] = str(root)
    tools.save_cfg(cfg)
    print(f"  EyeWitness root recorded: {root}")
    return True


INSTALLERS = {
    "bbot": install_bbot,
    "waymore": install_waymore,
    "cloud_enum": install_cloud_enum,
    "subfinder": install_subfinder,
    "eyewitness": install_eyewitness,
}


def install(names) -> list[str]:
    BIN_DIR.mkdir(parents=True, exist_ok=True)
    for prereq in ("git", "curl", "unzip"):
        if not tools.tool_bin(prereq):
            print(f"  warning: `{prereq}` not found on PATH; some steps may fail ({prereq} needed)")
    failures = []
    for name in names:
        build = INSTALLERS.get(name)
        if build is None:
            print(f"!! unknown tool '{name}' (choose from: {', '.join(INSTALLERS)})")
            failures.append(name)
            continue
        print(f"==> [{name}]")
        try:
            ok = build()
        except KeyboardInterrupt:
            raise
        except Exception as exc:  # keep installer moving even if one step explodes
            print(f"  !! unexpected error: {exc}")
            ok = False
        print(f"  {name}: {'OK' if ok else 'FAILED'}")
        if not ok:
            failures.append(name)
        tools.record_paths()
    print()
    return failures
