I want to build an auto ept tool that will combine several EPT tools and auto excute then based off a provided domain.

Tools include:
BBOT https://github.com/blacklanternsecurity/bbot.git
CloudEnum https://github.com/initstring/cloud_enum.git
eyewitness https://github.com/RedSiege/EyeWitness.git
subfinder https://github.com/projectdiscovery/subfinder.git  
waymore https://github.com/xnl-h4ck3r/waymore.git



--------------------------

All output should be consoldiated IE:
Usernames/emials combined 
subdomains etc
all similar items put into similar lists 

Input would be based off domains and for cloud enum the domains and possible shorthand as well 
It would be best to stick with an sh script to pass all the commands however if python is a better alt then use that.
end result shoudl allow an operator to pass a domain and let it run and get everything back. 
