#!/usr/bin/env bash
# EPT-auto entrypoint: thin wrapper around the python package in ./eptauto
set -euo pipefail
cd "$(dirname "$0")"
exec python3 -m eptauto.cli "$@"
