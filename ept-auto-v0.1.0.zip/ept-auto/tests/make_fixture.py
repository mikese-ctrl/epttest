"""Builds a small fake output tree so `ept-auto --consolidate-only` can be tested offline.

Usage: python3 tests/make_fixture.py [target_root]
Then:  ./ept-auto.sh example.com --consolidate-only --outdir <target_root>
"""

import sqlite3
import sys
from pathlib import Path


def main() -> None:
    root = Path(sys.argv[1] if len(sys.argv) > 1 else "smoke")
    domain_root = root / "example.com"
    if domain_root.exists():
        import shutil
        shutil.rmtree(domain_root)
    raw = domain_root / "raw"

    (raw / "subfinder").mkdir(parents=True, exist_ok=True)
    (raw / "subfinder" / "subs.txt").write_text(
        "api.example.com\nmail.example.com\nguest.example.com\nwww.example.com\nevil.notexample.com\n"
    )

    scan = raw / "bbot" / "ept-example-com-1"
    scan.mkdir(parents=True, exist_ok=True)
    (scan / "output.json").write_text(
        '{"type": "DNS_NAME", "data": "example.com", "resolved_hosts": ["93.184.216.34", "2606:2800:220:1:248:1893:25c8:1946"]}\n'
        '{"type": "DNS_NAME", "data": "portal.example.com", "module": "otx"}\n'
        '{"type": "DNS_NAME", "data": "*.example.com", "module": "dnsbrute"}\n'
        '{"type": "DNS_NAME_UNRESOLVED", "data": "stale.example.com", "module": "dnsgrep"}\n'
        '{"type": "DNS_NAME", "data": "hera.ns.cloudflare.com", "module": "NS", "resolved_hosts": ["108.162.192.162"]}\n'
        '{"type": "EMAIL_ADDRESS", "data": "Bob.Smith@EXAMPLE.com", "module": "github"}\n'
        '{"type": "GAME", "data": "garbage module", "ignored": true}\n'
        "not json line should be skipped\n"
        '{"type": "URL", "data_json": {"url": "https://staging.example.com/.git"}, "module": "http"}\n'
        '{"type": "URL", "data": "http://unrelated.example.io/nope", "module": "http"}\n'
        '{"type": "URL_UNVERIFIED", "data_json": {"url": "https://unverified.example.com/"}, "module": "asn"}\n'
        '{"type": "VIRTUAL_HOST", "data_json": {"host": "example.com", "url": "https://vhost.example.com/", "description": "200 OK"}, "module": "vhost-monster"}\n'
        '{"type": "STORAGE_BUCKET", "data_json": {"host": "stuff.s3.amazonaws.com", "url": "https://stuff.s3.amazonaws.com"}, "module": "awspermfeatures"}\n'
        '{"type": "AZURE_TENANT", "data_json": {"tenant-id": "abcxyz", "tenant-names": ["Example Corp"], "domains": ["examplecorp.com"]}, "module": "azuretenant"}\n'
        '{"type": "MOBILE_APP", "data_json": {"url": "https://apps.apple.com/us/app/example/id123", "id": "com.example.app"}, "module": "mobileapp"}\n'
        '{"type": "CODE_REPOSITORY", "data_json": {"url": "https://github.com/example/example-org"}, "module": "github-org"}\n'
        '{"type": "TECHNOLOGY", "data_json": {"host": "example.com", "technology": "Next.js"}, "module": "nuclei"}\n'
        '{"type": "WAF", "data_json": {"url": "https://example.com/", "host": "example.com", "waf": "Cloudflare"}, "module": "wafw00f"}\n'
        '{"type": "SOCIAL", "data_json": {"platform": "twitter", "profile_name": "ExampleCorp", "url": "https://x.com/ExampleCorp"}, "module": "social"}\n'
        '{"type": "USERNAME", "data": "ExampleCorp-Admin", "module": "cbm"}\n'
        '{"type": "OPEN_TCP_PORT", "data_json": {"host": "example.com", "port": 8080}, "module": "portscan", "tags": ["remote-port-open"]}\n'
        '{"type": "OPEN_TCP_PORT", "data_json": {"host": "example.com", "port": 443}, "module": "speculate", "tags": ["in-scope", "port-443"]}\n'
        '{"type": "PASSWORD", "data": "hunter2", "module": "nuclei", "tags": ["unauth"]}\n'
        '{"type": "STORAGE_BUCKET", "data": "https://example-stuff.s3.amazonaws.com", "module": "awspermfeatures"}\n'
        '{"type": "FINDING", "data_json": {"name": "Nuclei Vuln - GitLab", "severity": "HIGH", "description": "open git", "url": "https://staging.example.com/.git"}, "module": "nuclei"}\n'
    )

    (raw / "waymore").mkdir(parents=True, exist_ok=True)
    (raw / "waymore" / "waymore.txt").write_text(
        "https://mail.example.com/inbox?user=bob.smith@EXAMPLE.com#frag\n"
        "https://download.example.com/some/path?x=1\n"
        "https://blog.example.com/gene/\n"
        "https://other.example.com/\n"
        "mailto:nobody@evil.com\n"
    )

    ce = raw / "cloud_enum" / "run-x"
    ce.mkdir(parents=True, exist_ok=True)
    (ce / "findings.json").write_text(
        "#### CLOUD_ENUM 26/10/2026 12:00:00 ####\n"
        '{"access": "public", "msg": "Open Google Bucket", "target": "https://example-stuff.storage.googleapis.com"}\n'
        "garbage line\n"
        '{"access": "protected", "msg": "S3 bucket", "target": "http://example-stuff.s3.amazonaws.com/"}\n'
    )

    # per-run dir layout ept-auto now uses (see tools.build_eyewitness)
    db = raw / "eyewitness" / "run-fixture"
    db.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(db / "ew.db")
    con.execute("CREATE TABLE urls (id INTEGER, url TEXT, screenshot INTEGER, status_code INTEGER)")
    con.execute("INSERT INTO urls VALUES (1,'https://api.example.com:8443/v1/x',1,200)")
    con.execute("INSERT INTO urls VALUES (2,'http://mail.example.com/inbox?user=bob.smith@EXAMPLE.com',0,404)")
    con.commit()
    con.close()

    (raw / "logs").mkdir(parents=True, exist_ok=True)
    print(f"fixture ready at {root}")


if __name__ == "__main__":
    main()
