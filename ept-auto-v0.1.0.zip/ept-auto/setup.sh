#!/usr/bin/env bash
# EPT-auto installer: delegates to the python installer module.
set -euo pipefail
cd "$(dirname "$0")"
exec ./ept-auto.sh --install "$@"
